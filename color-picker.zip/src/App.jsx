const App = () => {
    return <h1>Color Picker Test</h1>;
};

export default App;
